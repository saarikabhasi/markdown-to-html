#!/usr/bin/env
import sys
import argparse
from . import markdown as md

def markdown(value=None):
   #  print("value",value)
  		
   md_object = md.markdown(value)
   return md_object.markdown_parser()

	
   #  newfile = open(str(filename.split(".")[0])+".html","w")
   #  print("newfile created",newfile)
   #  newfile.writelines(md.markdown(fileContents))
   #  print("newfwrite",newfile)
   #  newfile.close()
   #  print("File created")


def main():
   parser =argparse.ArgumentParser('Input a file')
   parser.add_argument('-f',type=argparse.FileType('r'))
   # parser.add_argument('--inputfile',type=argparse.FileType('r'))
   # parser.add_argument('--string',type=str,help='Input markdown string')
   args = parser.parse_args()
   # print("args",args)
   # if args.string:
   #    print("value")
   #    return markdown(value=args.string)
   if args.f:
      # print("inputfile",args.f)
     # newfile = open(str(args.f.name.split(".")[0])+".html","w")
      print(markdown(value=args.f.read())) 
      #newfile.close()

      # markdown(fileContents=args.inputfile.read(), filename=args.inputfile.name)



    



    
    
    


    



